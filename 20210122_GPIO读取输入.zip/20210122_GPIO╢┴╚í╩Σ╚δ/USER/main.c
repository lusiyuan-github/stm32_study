#include "stm32f10x.h"
#include "delay.h"
#include "led.h"
#include "key.h"
/************************************************
文档为自学目的，无商业用途
LED的配置和亮灯 闪烁
************************************************/


// void Delay(u32 count)
// {
//   u32 i=0;
//   for(;i<count;i++);
// }
 int main(void)
{	
	 char i;
   LED_Init();
	 delay_init();
	 KEY_Init();
  
 				//PA.5 输出高  
	while(1)
	{
	  i = GPIO_ReadInputDataBit(GPIOKEY , GPIO_Pin_KEY);
		if(i==i)
			GPIO_SetBits(GPIOLED , GPIO_Pin_LED);
		else if(i==0)
			GPIO_ResetBits(GPIOLED , GPIO_Pin_LED);
	}
}
