#ifndef __STM32F10X_KEY_H__
#define __STM32F10X_KEY_H__

#include "stm32f10x.h"
#define GPIO_Pin_KEY           GPIO_Pin_13
#define GPIOKEY                GPIOC
#define RCC_APB2Periph_GPIOKEY RCC_APB2Periph_GPIOC

void KEY_Init(void);

#endif