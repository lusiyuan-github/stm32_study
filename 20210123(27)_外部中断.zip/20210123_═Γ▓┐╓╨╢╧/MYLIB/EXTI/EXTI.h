#ifndef __STM32F10X_EXTI_H__
#define __STM32F10X_EXTI_H__

#include "stm32f10x.h"
#define GPIO_PortSource_GPIOX GPIO_PortSourceGPIOC
#define GPIO_PinSourceX GPIO_PinSource13
#define EXTI_LineX EXTI_Line13
void EXTI_Configure(void);

#endif